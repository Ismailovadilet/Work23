package com.company;

public class Class {
    int number;
    String word;
    int[]massiv=new int[5];


    public Class() {
    }


    public Class(int number, String word, int[] massiv) {
        this.number = number;
        this.word = word;
        this.massiv = massiv;
    }
}

