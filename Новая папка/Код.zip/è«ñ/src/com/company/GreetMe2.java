package com.company;

import java.util.Scanner;

public class GreetMe2 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("Салам я Java, а ты? ");
        System.out.println("Мен");
        String name=scanner.nextLine();
        System.out.println("Кайсыл жерде окуйсун? ");
        String school=scanner.nextLine();
        System.out.println("Эмне менен алектенесин? ");
        String work=scanner.nextLine();
        System.out.println(" Салам, " +name+ " мен " +school+ " да окуймун, " +work+
                " менен алектенемин");

    }
}
