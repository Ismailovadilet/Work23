package com.company;

public class Repetition {
    public static void main(String[] args) {
//        byte book= 10;
//        byte bag=35;
//        byte box= 25;
//        byte run= 20;
//        byte winter= 40;
//        byte window= 15;
//        byte rich= 30;
//        byte rum= 45;
//        byte cook= 50;
//        byte counter= 55;
//        System.out.println(book+bag+box+run+winter+window+rich+rum+cook+counter);
//
//        short books1= 10;
//        short bags1= 35;
//        short boxes1= 25;
//        short runs1= 20;
//        short winters1= 40;
//        short windows1= 15;
//        short riches1= 30;
//        short rums1= 45;
//        short cooks1= 50;
//        short counters1= 55;
//        System.out.println(books1+bags1+boxes1+runs1+winters1+windows1+riches1+rums1+cooks1+counters1);
//
//        int books= 10;
//        int bags= 35;
//        int boxes= 25;
//        int runs= 20;
//        int windows= 15;
//        int riches= 30;
//        int rums= 45;
//        int cooks= 50;
//        int counters= 55;
//        System.out.println(book+bag+box+run+winter+window+rich+rum+cook+counter);
//
//        long book1= 10;
//        long bag1= 35;
//        long box1= 25;
//        long run1= 20;
//        long winter1= 40;
//        long window1= 15;
//        long rich1= 30;
//        long rum1= 45;
//        long cook1= 50;
//        long counter1= 55;
//        System.out.println(book1+bag1+box1+run1+winter1+window1+rich1+rum1+cook1+counter1);
//
//        float book2= 10f;
//        float bag2= 35f;
//        float box2= 25f;
//        float run2= 20f;
//        float winter2= 40f;
//        float window2= 15f;
//        float rich2= 30f;
//        float rum2= 45f;
//        float cook2= 50f;
//        float counter2= 55f;
//        System.out.println(book2+bag2+box2+run2+winter2+window2+rich2+rum2+cook2+counter2);
//
//        double book3= 10;
//        double bag3= 35;
//        double box3= 25;
//        double run3= 20;
//        double winter3= 40;
//        double window3= 15;
//        double rich3= 30;
//        double rum3= 45;
//        double cook3= 50;
//        double counter3= 55;
//        System.out.println(book3+bag3+box3+run3+winter3+window3+rich3+rum3+cook3+counter3);
//
//        boolean books2= true;
//        boolean books3= false;
//        boolean bag4= true;
//        boolean bag5= false;
//        boolean box6= true;
//        boolean box7= false;
//        boolean run8= true;
//        boolean run9= false;
//        boolean winter10= true;
//        boolean winter10= false;
//        boolean window12= true;
//        boolean window13= false;
//        boolean rich14= true;
//        boolean rich15= false;
//        boolean rum16= true;
//        boolean rum17= false;
//        boolean cook18= true;
//        boolean cook19= false;
//        boolean counter20= true;
//        boolean counter21= false;




    }
}
