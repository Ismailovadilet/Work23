package com.company;

import java.util.Locale;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        //write your code here
//        System.out.println("Азамат               ");
//        System.out.println("       ойногону      ");
//        System.out.println("                кетти");
//
//        Scanner scanner=new Scanner(System.in);
//        System.out.println("Биринчи санды жазыныз: ");
//        int number1=scanner.nextInt();
//        System.out.println("Экинчи санды жазыныз: ");
//        int number2=scanner.nextInt();
//        System.out.println("Учунчу санды жазыныз: ");
//        int number3=scanner.nextInt();
//        int one=(number1+number2+number3);
//        System.out.println("Жообу " +one);
//        int one1=(number1*number2*number3);
//        System.out.println("Жообу " +one1);
//        double one2=(number1+number2+number3)/3.;
//        System.out.println("Жообу " +one2);

        /*  Scanner scanner = new Scanner(System.in);
        System.out.println("Биринчи санды жазыныз: ");
        int number1 = scanner.nextInt();

        System.out.println("Экинчи санды жазыныз: ");
        int number2 = scanner.nextInt();  

        System.out.println("Учунчу санды жазыныз: ");
        int number3 = scanner.nextInt();

        System.out.println("results");
        int sum=number1+number2+number3;
        System.out.println("5+7+8=20 " + sum);

        int d=number1*number2*number3;
        System.out.println("5*7*8=280 " + d);

        int a=((number1+number2+number3)/(number3-number1));
        System.out.println("(5+7+8)/3=6.6666666667");*/


//        Scanner counter=new Scanner(System.in);
//        System.out.println("Мурунку счет");
//        double lastNum=counter.nextDouble();
//
//        System.out.println("Азыркы счет");
//        double currentNum=counter.nextDouble();
//
//        System.out.println("Количество");
//        double per=counter.nextDouble();
//
//        double sum= (currentNum-lastNum)/per;
//
//        double tarif1,tarif2,tarif3;
//        tarif1=16.24;
//        tarif2=21.8;
//        tarif3=25.6;
//        System.out.println("");
//
//        System.out.println("Вы потребили:");
//        double level1=115*per;
//         double level2=(190-115)*per;
//        double level3=(sum-190)*per;
//
//        System.out.println("первый уровень: " +level1);
//        System.out.println("второй уровень: " +level2);
//        System.out.println("третий уровень: " +level3);
//        System.out.println("");
//
//        System.out.println("тариф:  " +tarif1+"  "+tarif2+"  "+tarif3);
//        System.out.println("");
//        System.out.println("К оплате:");
//        double finish1=tarif1*level1;
//        double finish2=tarif2*level2;
//        double finish3=tarif3*level3;
//
//        System.out.println("первый уровень " +finish1);
//        System.out.println("второй уровень " +finish2);
//        System.out.println("третий уровень " +finish3);
//        System.out.println("");
//
//        double итого1= level1*tarif1;
//        double итого2= level2*tarif2;
//        double итого3= level3*tarif3;
//        double big= итого1+итого2+итого3;
//        System.out.println("Общий счет " +big);
//
//        Scanner oclock=new Scanner(System.in);
//        System.out.println("Saat");
//        int One=oclock.nextInt();
//        int Two=oclock.nextInt();
//        int Three=oclock.nextInt();
//        int sum1=One*60*60;
//        int sum2=Two*60;
//        int sum3=Three*1;
//        int sum=sum1+sum2+sum3;
//        System.out.println();
//        System.out.println("Жообу " +sum);
//
//        Scanner sc=new Scanner(System.in);
//        int num=sc.nextInt();
//        int sum1=num%10;
//        int sum2=(num/10)%10;
//        int sum3=num/100;
//        System.out.println(sum3+ "," +sum2+ "," +sum1);
//
//        String name=("Barcelona");
//        System.out.println(name.length());
//        System.out.println(name.toUpperCase());
//        System.out.println(name.toLowerCase());
//        System.out.println(name.toString());
//
//        double a=9; double b=15;
//        System.out.println(Math.max(a,b));
//        System.out.println(Math.min(a,b));

//        Задание девятое
//        Scanner sc=new Scanner(System.in);
//        System.out.println("Сколько дней проживания");
//        int days= sc.nextInt();
//        int year=365;
//        int month=30;
//        int age= (days/year);
//        int age2= days-(age*year);
//        int age3= age2/month;
//        System.out.print(age+ " год, ");
//        System.out.println(age3+ " месяц");
//
    //        Задание десятое
    //        Scanner scanner=new Scanner(System.in);
    //        System.out.print("Your name:");
    //        String name1=sc.nextLine();
    //        System.out.print("Your age:");
    //        String name2=sc.nextLine();
    //        System.out.print("Your country:");
    //        String name3=sc.nextLine();
    //        System.out.print("Year of birth:");
    //        int name4=sc.nextInt();
    //        int name5=2019-name4;
    //        System.out.println();
    //        System.out.println("Your name is " +name1.toUpperCase()+ "  +name2.toUpperCase()+
    //                ". And you " +name5+ " years old, and you are from " +name3);
//
//     Задание восьмое
//        Scanner sc1 = new Scanner(System.in);
//        System.out.println("Write time");
//        int time1 = sc1.nextInt();
//        int time2 = 60;
//        int time3 = time1 % 5;
//
//        if (time3 == 0 || time3 == 4){
//        System.out.println("red");
//    }else {
//            System.out.println("green");
//        }



}
}