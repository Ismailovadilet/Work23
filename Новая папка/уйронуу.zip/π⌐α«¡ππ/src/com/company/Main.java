package com.company;

import java.util.Locale;
import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
//        // write your code here
//        String name= "Adilet";
//        System.out.println(name);
//        Scanner scanner=new Scanner(System.in);
//        System.out.println("eki san jazynyz");
//        int num1 = scanner.nextInt();
//        int num2 = scanner.nextInt();
//        System.out.println(num1+num2);

//        Random random=new Random();
//        int number=random.nextInt(10)+1;
//        System.out.println(number);

//        Random random=new Random();
//        int num1=random.nextInt(5);
//        int num2=random.nextInt(10);
//        int num3=random.nextInt(15);
//        int a=(num1+num2+num3)/3;
//        System.out.println(a);

//        String first="Адилет";
//        String last="Исмаилов";
//        String fullName="My name is %s %s!";
//        String name=String.format(fullName,first,last);
//        System.out.println(name);
//
//        String text=" Hello World ";
//        String cleanText=text.strip();
//        System.out.println("-" + text + "-");
//        System.out.println("-" + cleanText + "-");
//
//        String text="Hello Java-4 Peaksoft school";
//        System.out.println(text);
//        System.out.println(text.toLowerCase());
//        System.out.println(text.toUpperCase());

//        String text="Hello Java-4 Peaksoft school";
//        text=text.replace("Hello","Салам");
//        text=text.replace("school","мектеби");
//        System.out.println(text);

//        String first="Адилет";
//        String last="Исмаилов";
//        String msg="My name is "+first+" "+last+"!";
//        System.out.println(msg);

//        String f="|%s|%s|";
//        String row1=String.format(f, "Уулкан","Маматсакова");
//        String row2=String.format(f, "Адилет","Исмаилов");
//        String row3=String.format(f, "Нуриса","Мамираим кызы");
//        System.out.println(row1);
//        System.out.println(row2);
//        System.out.println(row3);

//        Random random=new Random();
//        int num1=random.nextInt(50);
//        System.out.println(num1);

//        String numberOne=("Как тебя зовут?");
//        String numberTwo=("Адилет");
//        System.out.println(numberOne);
//        System.out.println("Меня зовут " +numberTwo);

//Первый вариант:
//        Scanner counter=new Scanner(System.in);
//        System.out.println("Мурунку счет");
//        double lastNum=counter.nextDouble();
//
//        System.out.println("Азыркы счет");
//        double currentNum=counter.nextDouble();
//
//        System.out.println("Количество");
//        double per=counter.nextDouble();
//
//        double sum= Math.abs (currentNum-lastNum)/per;
//
//        double tarif1,tarif2,tarif3;
//        tarif1=16.24;
//        tarif2=21.8;
//        tarif3=25.6;
//        System.out.println("");
//
//        System.out.println("Вы потребили:");
//        double level1= 115*per;
//        double level2=(190-115)*per;
//        double level3=Math.abs(sum-190)*per;
//
//        System.out.println("первый уровень: " +Math.round (+level1)+ "kBt");
//        System.out.println("второй уровень: " +Math.round (+level2)+ "kBt");
//        System.out.println("третий уровень: " +Math.round (+level3)+ "kBt");
//        System.out.println("");
//
//        System.out.println("тариф:  " +tarif1+"  "+tarif2+"  "+tarif3);
//        System.out.println("");
//        System.out.println("К оплате:");
//        double finish1=tarif1*level1;
//        double finish2=tarif2*level2;
//        double finish3=tarif3*level3;
//
//        System.out.println("первый уровень " +finish1);
//        System.out.println("второй уровень " +finish2);
//        System.out.println("третий уровень " +finish3);
//        System.out.println("");
//
//        double итого1= level1*tarif1;
//        double итого2= level2*tarif2;
//        double итого3= level3*tarif3;
//        double big=Math.ceil  (итого1+итого2+итого3);
//        System.out.println("Общий счет " +big);

        /*Второй вариант:
        Scanner scanner = new Scanner(System.in);
        System.out.println("enter the start");
        int start=scanner.nextInt();
        System.out.println("enter the end");
        int end= scanner.nextInt();
        System.out.println("enter the quantity of people");
        int people=scanner.nextInt();

        double last= end-start;

        //tariff
        double tariff1, tariff2, tariff3;
        tariff1 = 16.24;
        tariff2 = 21.8;
        tariff3 = 25.6;

        //kilowatt
        double kilowatt1=115;
        double kilowatt2=190-115;

        //spent
        double spent1=kilowatt1*people;
        double spent2=kilowatt2*people;
        double spent3= last-(spent1+spent2);
        System.out.println("биринчи"+spent1);
        System.out.println("экинчи"+spent2);
        System.out.println("учунчу"+spent3);
        //total
        double total1=spent1*tariff1;
        double total2=spent2*tariff2;
        double total3=spent3*tariff3;
        System.out.println("биринчи"+total1);
        System.out.println("экинчи"+total2);
        System.out.println("учунчу"+total3);

        double result=total1+total2+total3;

        System.out.println(result);*/


//        Scanner scanner=new Scanner(System.in);
//        double a, b, c;
//        System.out.println("ax2+bx+c=0");
//        System.out.println("Введите значение а: ");
//        a=scanner.nextDouble();
//
//        System.out.println("Введите значение b: ");
//        b=scanner.nextDouble();
//
//        System.out.println("Введите значение с: ");
//        c=scanner.nextDouble();
//
//        double D=b*b-4*a*c;
//        double х1,х2;
//        х1=(-b+Math.sqrt(D))/(2*a);
//        х2=(-b-Math.sqrt(D))/(2*a);
//        System.out.println("Первый корень урав: " +х1);
//        System.out.println("Второй корень урав: " +х2);

//        String text="Hello Java-4 Peaksoft school";
//        System.out.println(text);
//        System.out.println(text.toLowerCase());
//        System.out.println(text.toUpperCase());

//        Вторник
//        String text="Дордой";
//        System.out.println(text);
//        System.out.println(text.toUpperCase());

//        int num1=8;
//        int num2=11;
//        boolean sum=(num1>num2);
//
//        if (num1>num2){
//            System.out.println(num1);
//
//        } else {
//            System.out.println(num2);
//        }
//
//
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("Жашыныз канчада?");
//        int age = scanner.nextInt();
//
//        if (age >= 18){
//        System.out.println("Алкоголь 18жаштан жогору болсо сатылат");
//    }else{
//        System.out.println("Сизге сатылбайт");
//
//    }
//
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("Кайсы курсту тандайсыз?");
//        String kurs=scanner.nextLine();
//
//        switch (kurs){
//            case "USD":
//                System.out.println("84,5");
//                break;
//            case "EUR":
//                System.out.println("102.58");
//                break;
//            case "RUB":
//                System.out.println("1.15");
//                break;
//            case "KZT":
//                System.out.println("0.20");
//                break;
//            default:
//                System.out.println("Мындай курс жок!");
//        }
//        Scanner scanner = new Scanner(System.in);
//        int a = scanner.nextInt();
//        int b = scanner.nextInt();
//        int c;
//
//        if (a > b){
//            c = 100;
//    }else{
//            c = 50;
//        }
//            c = a > b? 100 : 50;
//        System.out.println(c);

//        int a, b;
//        a = 20;
//        b = (a == 15) ? 25 : 35;
//        System.out.println("Значение b1: " + b);
//        b = (a == 20) ? 25 : 35;
//        System.out.println("Значение b2: " + b);

//Вторник
//        String teht=("e;d;");
//        System.out.println(teht);
//        teht=teht.replace("e","i");
//        teht=teht.replace("d","t");
//        System.out.println(teht);

//        String name="Peaksoft House, Peaksoft school";
//        boolean empty=name.isEmpty();
//        System.out.println("Строка пустойбу:"+empty);
//        int index=name.lastIndexOf("c");
//        System.out.println(index);
//
//        int a = 11;
//        int b = 8;
//        int c = a > b ? (a+b) : (a-b);
//        System.out.println(c);
//
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Скорость в км в час:");
//        double kmCH = sc.nextDouble();
//
//        System.out.println(2"Скорость в метр в сек:");
//        double metrS = sc.nextDouble();
//
//        double kmMetr = (kmCH * 1000) / 3600;
//
//        if (kmCH > 0 && metrS > 0) {
//            if (kmCH > metrS) {
//                String num1 = "Скорость %s км/ч больше чем %s км/с";
//                String age1 = String.format(num1, kmCH, metrS);
//                System.out.println(age1);
//            } else if (metrS > kmCH) {
//                String num2 = "Скорость %s км/с больше чем %s км/ч";
//                String age2 = String.format(num2, kmCH, metrS);
//                System.out.println(age2);
//            } else {
//                String num3 = "Скорость %s км/ч и %s км/с равны:";
//                String age3 = String.format(num3, kmCH, metrS);
//                System.out.println(age3);
//            }
//        }else {
//            System.out.println("!!! Скорость равен 0 или - !!!");
//        }
//        sc.close();

//        Scanner qw = new Scanner(System.in);
//        System.out.println("Скорость в км/ч");
//        double Ema = qw.nextDouble();
//
//        System.out.println("Скорость в км/с");
//        double Joma = qw.nextDouble();
//
//        double mac = (Ema * 1000) / 3600;
//
//        if (Ema > 0 && Joma > 0) {
//            }if (mac > Joma) {
//            System.out.println("Скорость км/ч больше чем км/с");
//        }else if (mac < Joma){
//            System.out.println("Скорость км/с больше чем км/ч");
//        }else {
//            System.out.println("Скорость км/ч и км/с равны");
//        }


//        Scanner scanner=new Scanner(System.in);
//        System.out.println("Бир санды жазыныз:");
//        int a=scanner.nextInt();
//        int b=0;
//        while (b>0){
//            System.out.println("");
//            b++;
//        }




    }

    }







