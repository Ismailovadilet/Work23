package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        String name1 = "Исмаилов";
        String name2 = "Адилет";
        System.out.println (name1 + name2);
        int a = 21;
        System.out.println ("21");

    }
}
