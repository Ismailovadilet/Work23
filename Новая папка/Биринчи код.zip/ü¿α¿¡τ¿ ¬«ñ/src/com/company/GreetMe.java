package com.company;

import java.util.Scanner;

public class GreetMe {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("Салам я Java, а ты? ");
        System.out.println("Мен ");
        String name=scanner.nextLine();
        System.out.println("Сен канча жаштасын ?");
        String age=scanner.nextLine();
        System.out.println("Сен кайсы шаарда жашайсын ?");
        String city = scanner.nextLine();
        System.out.println("Салам , " +name+ " мен " +city+ " шаарда жашайм, " + " мен " +age+ " жаштамын " );
    }
}

