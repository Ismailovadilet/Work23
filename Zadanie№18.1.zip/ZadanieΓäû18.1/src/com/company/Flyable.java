package com.company;

public interface Flyable {
    void fly();
}


