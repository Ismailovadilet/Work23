package com.company;

public class Student {
     String name;
     int age;
     String university;
     String profession;

}
